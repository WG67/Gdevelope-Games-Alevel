gdjs.New_32sceneCode = {};
gdjs.New_32sceneCode.GDPlayerObjects1_1final = [];

gdjs.New_32sceneCode.GDSkeletObjects1= [];
gdjs.New_32sceneCode.GDSkeletObjects2= [];
gdjs.New_32sceneCode.GDSkeletObjects3= [];
gdjs.New_32sceneCode.GDPlayerObjects1= [];
gdjs.New_32sceneCode.GDPlayerObjects2= [];
gdjs.New_32sceneCode.GDPlayerObjects3= [];
gdjs.New_32sceneCode.GDKnightSwordObjects1= [];
gdjs.New_32sceneCode.GDKnightSwordObjects2= [];
gdjs.New_32sceneCode.GDKnightSwordObjects3= [];
gdjs.New_32sceneCode.GDNecromancer_95leftObjects1= [];
gdjs.New_32sceneCode.GDNecromancer_95leftObjects2= [];
gdjs.New_32sceneCode.GDNecromancer_95leftObjects3= [];
gdjs.New_32sceneCode.GDNecromancerObjects1= [];
gdjs.New_32sceneCode.GDNecromancerObjects2= [];
gdjs.New_32sceneCode.GDNecromancerObjects3= [];
gdjs.New_32sceneCode.GDWallBannerGreenObjects1= [];
gdjs.New_32sceneCode.GDWallBannerGreenObjects2= [];
gdjs.New_32sceneCode.GDWallBannerGreenObjects3= [];
gdjs.New_32sceneCode.GDWallGooObjects1= [];
gdjs.New_32sceneCode.GDWallGooObjects2= [];
gdjs.New_32sceneCode.GDWallGooObjects3= [];
gdjs.New_32sceneCode.GDWall2Objects1= [];
gdjs.New_32sceneCode.GDWall2Objects2= [];
gdjs.New_32sceneCode.GDWall2Objects3= [];
gdjs.New_32sceneCode.GDWallObjects1= [];
gdjs.New_32sceneCode.GDWallObjects2= [];
gdjs.New_32sceneCode.GDWallObjects3= [];
gdjs.New_32sceneCode.GDTiledGooObjects1= [];
gdjs.New_32sceneCode.GDTiledGooObjects2= [];
gdjs.New_32sceneCode.GDTiledGooObjects3= [];
gdjs.New_32sceneCode.GDFloor2Objects1= [];
gdjs.New_32sceneCode.GDFloor2Objects2= [];
gdjs.New_32sceneCode.GDFloor2Objects3= [];
gdjs.New_32sceneCode.GDFloorObjects1= [];
gdjs.New_32sceneCode.GDFloorObjects2= [];
gdjs.New_32sceneCode.GDFloorObjects3= [];
gdjs.New_32sceneCode.GDChest_95checkpointObjects1= [];
gdjs.New_32sceneCode.GDChest_95checkpointObjects2= [];
gdjs.New_32sceneCode.GDChest_95checkpointObjects3= [];
gdjs.New_32sceneCode.GDChestObjects1= [];
gdjs.New_32sceneCode.GDChestObjects2= [];
gdjs.New_32sceneCode.GDChestObjects3= [];
gdjs.New_32sceneCode.GDCrateObjects1= [];
gdjs.New_32sceneCode.GDCrateObjects2= [];
gdjs.New_32sceneCode.GDCrateObjects3= [];
gdjs.New_32sceneCode.GDGreenMagicStaffObjects1= [];
gdjs.New_32sceneCode.GDGreenMagicStaffObjects2= [];
gdjs.New_32sceneCode.GDGreenMagicStaffObjects3= [];
gdjs.New_32sceneCode.GDnecromancer_95proObjects1= [];
gdjs.New_32sceneCode.GDnecromancer_95proObjects2= [];
gdjs.New_32sceneCode.GDnecromancer_95proObjects3= [];
gdjs.New_32sceneCode.GDenemy_95deadObjects1= [];
gdjs.New_32sceneCode.GDenemy_95deadObjects2= [];
gdjs.New_32sceneCode.GDenemy_95deadObjects3= [];
gdjs.New_32sceneCode.GDDoorObjects1= [];
gdjs.New_32sceneCode.GDDoorObjects2= [];
gdjs.New_32sceneCode.GDDoorObjects3= [];
gdjs.New_32sceneCode.GDUiHeartObjects1= [];
gdjs.New_32sceneCode.GDUiHeartObjects2= [];
gdjs.New_32sceneCode.GDUiHeartObjects3= [];
gdjs.New_32sceneCode.GDNewObjectObjects1= [];
gdjs.New_32sceneCode.GDNewObjectObjects2= [];
gdjs.New_32sceneCode.GDNewObjectObjects3= [];
gdjs.New_32sceneCode.GDNewObject2Objects1= [];
gdjs.New_32sceneCode.GDNewObject2Objects2= [];
gdjs.New_32sceneCode.GDNewObject2Objects3= [];
gdjs.New_32sceneCode.GDedgeObjects1= [];
gdjs.New_32sceneCode.GDedgeObjects2= [];
gdjs.New_32sceneCode.GDedgeObjects3= [];

gdjs.New_32sceneCode.conditionTrue_0 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_0 = {val:false};
gdjs.New_32sceneCode.conditionTrue_1 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_1 = {val:false};


gdjs.New_32sceneCode.eventsList0 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList1 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.New_32sceneCode.GDPlayerObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDSkeletObjects1Objects = Hashtable.newFrom({"Skelet": gdjs.New_32sceneCode.GDSkeletObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDSkeletObjects1Objects = Hashtable.newFrom({"Skelet": gdjs.New_32sceneCode.GDSkeletObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.New_32sceneCode.GDPlayerObjects1});gdjs.New_32sceneCode.eventsList2 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.New_32sceneCode.GDPlayerObjects1, gdjs.New_32sceneCode.GDPlayerObjects2);


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects2[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects2[k] = gdjs.New_32sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects2.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects2[i].setAnimationName("Run");
}
}}

}


{

/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].setAnimationName("Idle");
}
}}

}


};gdjs.New_32sceneCode.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.New_32sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.New_32sceneCode.eventsList5 = function(runtimeScene) {

{

/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariableNumber(gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].setAnimationName("Sword_right");
}
}}

}


};gdjs.New_32sceneCode.eventsList6 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDnecromancer_9595proObjects1Objects = Hashtable.newFrom({"necromancer_pro": gdjs.New_32sceneCode.GDnecromancer_95proObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDnecromancer_9595proObjects1Objects = Hashtable.newFrom({"necromancer_pro": gdjs.New_32sceneCode.GDnecromancer_95proObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.New_32sceneCode.GDPlayerObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDNecromancer_9595leftObjects1Objects = Hashtable.newFrom({"Necromancer_left": gdjs.New_32sceneCode.GDNecromancer_95leftObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.New_32sceneCode.GDPlayerObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDNecromancerObjects1Objects = Hashtable.newFrom({"Necromancer": gdjs.New_32sceneCode.GDNecromancerObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDnecromancer_9595proObjects1Objects = Hashtable.newFrom({"necromancer_pro": gdjs.New_32sceneCode.GDnecromancer_95proObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.New_32sceneCode.GDPlayerObjects1});gdjs.New_32sceneCode.eventsList7 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.New_32sceneCode.GDPlayerObjects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDChest_9595checkpointObjects1Objects = Hashtable.newFrom({"Chest_checkpoint": gdjs.New_32sceneCode.GDChest_95checkpointObjects1});gdjs.New_32sceneCode.eventsList8 = function(runtimeScene) {

};gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDFloor2Objects1Objects = Hashtable.newFrom({"Floor2": gdjs.New_32sceneCode.GDFloor2Objects1});gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.New_32sceneCode.GDPlayerObjects1});gdjs.New_32sceneCode.eventsList9 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList10 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList11 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList12 = function(runtimeScene) {

};gdjs.New_32sceneCode.eventsList13 = function(runtimeScene) {

{


gdjs.New_32sceneCode.eventsList0(runtimeScene);
}


{


{
}

}


{


{
}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].flipX(false);
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].flipX(true);
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").ignoreDefaultControls(true);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}}

}


{


{
}

}


{


gdjs.New_32sceneCode.eventsList1(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skelet"), gdjs.New_32sceneCode.GDSkeletObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDSkeletObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSkeletObjects1[i].addForceTowardObject((gdjs.New_32sceneCode.GDPlayerObjects1.length !== 0 ? gdjs.New_32sceneCode.GDPlayerObjects1[0] : null), 10, 0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSkeletObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSkeletObjects1[i].setAnimation(2);
}
}}

}


{


{
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skelet"), gdjs.New_32sceneCode.GDSkeletObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDSkeletObjects1Objects, false, runtimeScene, false);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariableNumber(gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.New_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDSkeletObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDSkeletObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSkeletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skelet"), gdjs.New_32sceneCode.GDSkeletObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDSkeletObjects1Objects, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CheckpointY")));
}
}}

}


{


gdjs.New_32sceneCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariableNumber(gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.New_32sceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition1IsTrue_0;
gdjs.New_32sceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9708244);
}
}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].returnVariable(gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(0);
}
}
{ //Subevents
gdjs.New_32sceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


{
}

}


{

gdjs.New_32sceneCode.GDPlayerObjects1.length = 0;


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition0IsTrue_0;
gdjs.New_32sceneCode.GDPlayerObjects1_1final.length = 0;gdjs.New_32sceneCode.condition0IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects2);
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects2[i].isCurrentAnimationName("Sword_right") ) {
        gdjs.New_32sceneCode.condition0IsTrue_1.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects2[k] = gdjs.New_32sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects2.length = k;if( gdjs.New_32sceneCode.condition0IsTrue_1.val ) {
    gdjs.New_32sceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.New_32sceneCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.New_32sceneCode.GDPlayerObjects1_1final.indexOf(gdjs.New_32sceneCode.GDPlayerObjects2[j]) === -1 )
            gdjs.New_32sceneCode.GDPlayerObjects1_1final.push(gdjs.New_32sceneCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.New_32sceneCode.GDPlayerObjects1_1final, gdjs.New_32sceneCode.GDPlayerObjects1);
}
}
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects1[i].hasAnimationEnded() ) {
        gdjs.New_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].returnVariable(gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").setMaxSpeed(120);
}
}}

}


{


{
}

}


{


gdjs.New_32sceneCode.eventsList6(runtimeScene);
}


{


{
gdjs.copyArray(runtimeScene.getObjects("Necromancer"), gdjs.New_32sceneCode.GDNecromancerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDNecromancerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNecromancerObjects1[i].addForceTowardObject((gdjs.New_32sceneCode.GDPlayerObjects1.length !== 0 ? gdjs.New_32sceneCode.GDPlayerObjects1[0] : null), 10, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Necromancer"), gdjs.New_32sceneCode.GDNecromancerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("necromancer_pro"), gdjs.New_32sceneCode.GDnecromancer_95proObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDNecromancerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNecromancerObjects1[i].getBehavior("FireBullet").Fire((gdjs.New_32sceneCode.GDNecromancerObjects1[i].getPointX("")), (gdjs.New_32sceneCode.GDNecromancerObjects1[i].getPointY("")), gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDnecromancer_9595proObjects1Objects, (( gdjs.New_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDPlayerObjects1[0].getAnimationFrame()), 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Necromancer_left"), gdjs.New_32sceneCode.GDNecromancer_95leftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDNecromancer_95leftObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNecromancer_95leftObjects1[i].addForceTowardObject((gdjs.New_32sceneCode.GDPlayerObjects1.length !== 0 ? gdjs.New_32sceneCode.GDPlayerObjects1[0] : null), 10, 0);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Necromancer_left"), gdjs.New_32sceneCode.GDNecromancer_95leftObjects1);
gdjs.copyArray(runtimeScene.getObjects("necromancer_pro"), gdjs.New_32sceneCode.GDnecromancer_95proObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDNecromancer_95leftObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNecromancer_95leftObjects1[i].getBehavior("FireBullet").Fire((gdjs.New_32sceneCode.GDNecromancer_95leftObjects1[i].getPointX("")), (gdjs.New_32sceneCode.GDNecromancer_95leftObjects1[i].getPointY("")), gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDnecromancer_9595proObjects1Objects, 180, 500, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Necromancer_left"), gdjs.New_32sceneCode.GDNecromancer_95leftObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDNecromancer_9595leftObjects1Objects, false, runtimeScene, false);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariableNumber(gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.New_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDNecromancer_95leftObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDNecromancer_95leftObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNecromancer_95leftObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Necromancer"), gdjs.New_32sceneCode.GDNecromancerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDNecromancerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariableNumber(gdjs.New_32sceneCode.GDPlayerObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs.New_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects1[k] = gdjs.New_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects1.length = k;}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDNecromancerObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDNecromancerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNecromancerObjects1[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDNecromancerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNecromancerObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("necromancer_pro"), gdjs.New_32sceneCode.GDnecromancer_95proObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDnecromancer_9595proObjects1Objects, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CheckpointX")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("CheckpointY")));
}
}}

}


{


gdjs.New_32sceneCode.eventsList7(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Chest_checkpoint"), gdjs.New_32sceneCode.GDChest_95checkpointObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDChest_9595checkpointObjects1Objects, false, runtimeScene, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDChest_95checkpointObjects1 */
{runtimeScene.getVariables().get("CheckpointX").setNumber((( gdjs.New_32sceneCode.GDChest_95checkpointObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDChest_95checkpointObjects1[0].getPointX("")));
}{runtimeScene.getVariables().get("CheckpointX").setNumber((( gdjs.New_32sceneCode.GDChest_95checkpointObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDChest_95checkpointObjects1[0].getPointY("")));
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);
{runtimeScene.getVariables().get("CheckpointX").setNumber((( gdjs.New_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDPlayerObjects1[0].getPointX("")));
}{runtimeScene.getVariables().get("CheckpointX").setNumber((( gdjs.New_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDPlayerObjects1[0].getPointY("")));
}}

}


{


{
}

}


{


{
}

}


{


gdjs.New_32sceneCode.eventsList8(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Floor2"), gdjs.New_32sceneCode.GDFloor2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.New_32sceneCode.GDPlayerObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
gdjs.New_32sceneCode.condition2IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Timer") >= 10;
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDFloor2Objects1Objects, gdjs.New_32sceneCode.mapOfGDgdjs_46New_9532sceneCode_46GDPlayerObjects1Objects, false, runtimeScene, false);
}if ( gdjs.New_32sceneCode.condition1IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition2IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}}
}
if (gdjs.New_32sceneCode.condition2IsTrue_0.val) {
/* Reuse gdjs.New_32sceneCode.GDFloor2Objects1 */
{for(var i = 0, len = gdjs.New_32sceneCode.GDFloor2Objects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFloor2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.New_32sceneCode.eventsList9(runtimeScene);
}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Timer");
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("NewObject"), gdjs.New_32sceneCode.GDNewObjectObjects1);
{for(var i = 0, len = gdjs.New_32sceneCode.GDNewObjectObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDNewObjectObjects1[i].setString("0" + gdjs.evtTools.common.toString(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Timer")));
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Timer") >= 90;
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "New scene", false);
}}

}


{


{
}

}


{


gdjs.New_32sceneCode.eventsList10(runtimeScene);
}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Timer") >= 1;
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.New_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Quit");
}}

}


{


gdjs.New_32sceneCode.eventsList11(runtimeScene);
}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "My Song 4.wav", true, 50, 1);
}}

}


{


gdjs.New_32sceneCode.eventsList12(runtimeScene);
}


{


{
}

}


};

gdjs.New_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.New_32sceneCode.GDSkeletObjects1.length = 0;
gdjs.New_32sceneCode.GDSkeletObjects2.length = 0;
gdjs.New_32sceneCode.GDSkeletObjects3.length = 0;
gdjs.New_32sceneCode.GDPlayerObjects1.length = 0;
gdjs.New_32sceneCode.GDPlayerObjects2.length = 0;
gdjs.New_32sceneCode.GDPlayerObjects3.length = 0;
gdjs.New_32sceneCode.GDKnightSwordObjects1.length = 0;
gdjs.New_32sceneCode.GDKnightSwordObjects2.length = 0;
gdjs.New_32sceneCode.GDKnightSwordObjects3.length = 0;
gdjs.New_32sceneCode.GDNecromancer_95leftObjects1.length = 0;
gdjs.New_32sceneCode.GDNecromancer_95leftObjects2.length = 0;
gdjs.New_32sceneCode.GDNecromancer_95leftObjects3.length = 0;
gdjs.New_32sceneCode.GDNecromancerObjects1.length = 0;
gdjs.New_32sceneCode.GDNecromancerObjects2.length = 0;
gdjs.New_32sceneCode.GDNecromancerObjects3.length = 0;
gdjs.New_32sceneCode.GDWallBannerGreenObjects1.length = 0;
gdjs.New_32sceneCode.GDWallBannerGreenObjects2.length = 0;
gdjs.New_32sceneCode.GDWallBannerGreenObjects3.length = 0;
gdjs.New_32sceneCode.GDWallGooObjects1.length = 0;
gdjs.New_32sceneCode.GDWallGooObjects2.length = 0;
gdjs.New_32sceneCode.GDWallGooObjects3.length = 0;
gdjs.New_32sceneCode.GDWall2Objects1.length = 0;
gdjs.New_32sceneCode.GDWall2Objects2.length = 0;
gdjs.New_32sceneCode.GDWall2Objects3.length = 0;
gdjs.New_32sceneCode.GDWallObjects1.length = 0;
gdjs.New_32sceneCode.GDWallObjects2.length = 0;
gdjs.New_32sceneCode.GDWallObjects3.length = 0;
gdjs.New_32sceneCode.GDTiledGooObjects1.length = 0;
gdjs.New_32sceneCode.GDTiledGooObjects2.length = 0;
gdjs.New_32sceneCode.GDTiledGooObjects3.length = 0;
gdjs.New_32sceneCode.GDFloor2Objects1.length = 0;
gdjs.New_32sceneCode.GDFloor2Objects2.length = 0;
gdjs.New_32sceneCode.GDFloor2Objects3.length = 0;
gdjs.New_32sceneCode.GDFloorObjects1.length = 0;
gdjs.New_32sceneCode.GDFloorObjects2.length = 0;
gdjs.New_32sceneCode.GDFloorObjects3.length = 0;
gdjs.New_32sceneCode.GDChest_95checkpointObjects1.length = 0;
gdjs.New_32sceneCode.GDChest_95checkpointObjects2.length = 0;
gdjs.New_32sceneCode.GDChest_95checkpointObjects3.length = 0;
gdjs.New_32sceneCode.GDChestObjects1.length = 0;
gdjs.New_32sceneCode.GDChestObjects2.length = 0;
gdjs.New_32sceneCode.GDChestObjects3.length = 0;
gdjs.New_32sceneCode.GDCrateObjects1.length = 0;
gdjs.New_32sceneCode.GDCrateObjects2.length = 0;
gdjs.New_32sceneCode.GDCrateObjects3.length = 0;
gdjs.New_32sceneCode.GDGreenMagicStaffObjects1.length = 0;
gdjs.New_32sceneCode.GDGreenMagicStaffObjects2.length = 0;
gdjs.New_32sceneCode.GDGreenMagicStaffObjects3.length = 0;
gdjs.New_32sceneCode.GDnecromancer_95proObjects1.length = 0;
gdjs.New_32sceneCode.GDnecromancer_95proObjects2.length = 0;
gdjs.New_32sceneCode.GDnecromancer_95proObjects3.length = 0;
gdjs.New_32sceneCode.GDenemy_95deadObjects1.length = 0;
gdjs.New_32sceneCode.GDenemy_95deadObjects2.length = 0;
gdjs.New_32sceneCode.GDenemy_95deadObjects3.length = 0;
gdjs.New_32sceneCode.GDDoorObjects1.length = 0;
gdjs.New_32sceneCode.GDDoorObjects2.length = 0;
gdjs.New_32sceneCode.GDDoorObjects3.length = 0;
gdjs.New_32sceneCode.GDUiHeartObjects1.length = 0;
gdjs.New_32sceneCode.GDUiHeartObjects2.length = 0;
gdjs.New_32sceneCode.GDUiHeartObjects3.length = 0;
gdjs.New_32sceneCode.GDNewObjectObjects1.length = 0;
gdjs.New_32sceneCode.GDNewObjectObjects2.length = 0;
gdjs.New_32sceneCode.GDNewObjectObjects3.length = 0;
gdjs.New_32sceneCode.GDNewObject2Objects1.length = 0;
gdjs.New_32sceneCode.GDNewObject2Objects2.length = 0;
gdjs.New_32sceneCode.GDNewObject2Objects3.length = 0;
gdjs.New_32sceneCode.GDedgeObjects1.length = 0;
gdjs.New_32sceneCode.GDedgeObjects2.length = 0;
gdjs.New_32sceneCode.GDedgeObjects3.length = 0;

gdjs.New_32sceneCode.eventsList13(runtimeScene);
return;

}

gdjs['New_32sceneCode'] = gdjs.New_32sceneCode;
