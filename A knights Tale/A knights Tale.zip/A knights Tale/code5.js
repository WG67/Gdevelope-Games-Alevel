gdjs.SettingsCode = {};

gdjs.SettingsCode.conditionTrue_0 = {val:false};
gdjs.SettingsCode.condition0IsTrue_0 = {val:false};


gdjs.SettingsCode.eventsList0 = function(runtimeScene) {

};

gdjs.SettingsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.SettingsCode.eventsList0(runtimeScene);

return;

}

gdjs['SettingsCode'] = gdjs.SettingsCode;
